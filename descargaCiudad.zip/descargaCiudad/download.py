import urllib.request
import pandas as pd

df = pd.read_csv('data.csv')

for i in range(0,4000):
    url = 'http://www.cs.ucf.edu/~aroshan/index_files/Dataset_PitOrlManh/images/'+df['file'].values[i]
    print("Download: ",url)
    urllib.request.urlretrieve(url, './sTest/'+df['file'].values[i])


for i in range(4000,8000):
    url = 'http://www.cs.ucf.edu/~aroshan/index_files/Dataset_PitOrlManh/images/'+df['file'].values[i]
    print("Download: ",url)
    urllib.request.urlretrieve(url, './sTrain/'+df['file'].values[i])
