# INstrucciones

Este scrip descarga:
- 4000 imagenes de ciudad para entrenamiento
- 4000 imagenes de ciudad para validar

Las imagenes se guardan en los directorios
- sTest
- STrain

Se requiere instalar:
sudo python3 -m pip install requests
sudo apt-get install python3-requests

Ejecutar:

python3 download.py
